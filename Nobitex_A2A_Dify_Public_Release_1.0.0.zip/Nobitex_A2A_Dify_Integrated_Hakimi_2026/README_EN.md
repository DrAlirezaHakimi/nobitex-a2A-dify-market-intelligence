# Nobitex A2A × Dify — Integrated Market Intelligence

A read-only market intelligence demonstration using public Nobitex market data, a Python/FastAPI backend, five logical A2A agents, a local HTML dashboard, and optional Dify Workflow / LLM explanation.

## Interactive setup guide

Open [USER_GUIDE_BILINGUAL.html](USER_GUIDE_BILINGUAL.html) in a browser for a bilingual, offline-friendly, step-by-step installation and Dify integration walkthrough.

## What it does

- Retrieves public bulk order-book and market-statistics snapshots from Nobitex in `live` mode.
- Screens the returned spot-market universe for data quality, freshness, spread, liquidity and market status.
- Runs bounded parallel analysis through five logical agents: orderflow, trend, liquidity, risk and decision.
- Exposes a protected FastAPI backend on port `8000` and a private loopback dashboard on port `8001`.
- Supports direct local analysis and optional server-to-server execution of a published Dify Workflow.
- Stores a small local SQLite execution history.
- Includes two importable Dify DSL examples: a base workflow and an optional LLM explainer.

## Safety and interpretation

- First-run default is `MARKET_MODE=demo`; all demo values are synthetic and clearly labelled.
- `MARKET_MODE=live` reads public market data only. No private account, wallet, or order endpoint is used.
- No real order placement is implemented. `execution_enabled` is always `false`.
- `SELL` means reduce/exit an already-owned spot position; short selling and margin are not supported.
- Scores are uncalibrated heuristic rankings, **not** probabilities of winning or expected returns.
- Stop/target levels and sizing are illustrative calculations, not validated trading instructions.
- The A2A implementation is a limited JSON-RPC subset based on A2A v0.2.6 concepts. It is not claimed to be fully compliant with the current A2A SDK/specification.

## Requirements

- Python 3.12+ (the included Dockerfile uses Python 3.12).
- Windows, Linux, or Docker Engine with Docker Compose.
- Internet access to Nobitex public APIs for `live` mode.
- Optional: a Dify Cloud or self-hosted instance with a published Workflow and a configured model for the LLM variant.
- Optional: a public HTTPS tunnel/reverse proxy for Dify Cloud to reach the local A2A backend. Never expose the dashboard port `8001`.

## Windows quick start

1. Extract the repository to a normal local folder.
2. Install Python 3.12+ and ensure the Python launcher `py` is available.
3. Run `start_windows.bat`.
4. The script installs requirements, creates a local `.env` with a random A2A key if missing, and starts both services.
5. Open <http://127.0.0.1:8001>.

The default mode is `demo`. To opt into public market data, edit the generated `.env` file and set:

```ini
MARKET_MODE=live
```

Restart the application after changing `.env`. In `live` mode, failure to reach the public exchange API is reported as an error; synthetic values are never substituted for live data.

## Linux

```bash
chmod +x start_linux.sh run_linux.sh
./start_linux.sh
```

Open <http://127.0.0.1:8001>. Edit `.env` to enable `MARKET_MODE=live` if required.

## Docker

Create `.env` first (the Windows startup script can generate it), ensure `API_KEY` is at least 24 characters, and run:

```bash
docker compose up --build -d
```

The Compose file binds host ports to `127.0.0.1` only. Do not run the native Windows startup and Docker Compose simultaneously on the same ports. Runtime SQLite data is stored under `./data` and is ignored by Git.

## Environment variables

| Variable | Purpose | Default / guidance |
|---|---|---|
| `MARKET_MODE` | `demo` or `live` | `demo` in the public release; set `live` explicitly to read public exchange data |
| `API_KEY` | Protects backend `/api/scan`, `/api/paper/preview`, and A2A RPC routes | Generated locally by bootstrap; keep secret |
| `PUBLIC_BASE_URL` | HTTPS base URL used in Agent Cards and Dify workflow input | Set to the active HTTPS tunnel/reverse-proxy URL; no trailing slash |
| `DIFY_API_KEY` | Dify Service API key used by the local dashboard to call Dify | Optional; store only in `.env` |
| `DIFY_API_BASE` | Dify API base URL | `https://api.dify.ai/v1` |
| `MARKET_TTL` | Market snapshot cache duration in seconds | `70` |
| `MAX_PARALLEL` | Maximum concurrent analysis tasks | `12` (hard capped at 20) |
| `MAX_DEEP` | Maximum eligible markets receiving deep analysis | `300` (hard capped at 1000) |
| `UI_MAX_AGE_SECONDS` | Maximum age accepted by the UI gateway | `200` |

Never commit `.env`. `.env.example` contains placeholders only.

## Dify integration

Two workflow templates are in `dify/`:

- `Hakimi_Nobitex_A2A_Gateway.yaml`: base workflow without an LLM node.
- `Hakimi_A2A_Optional_LLM_Explainer.yaml`: optional LLM text explanation after deterministic Python calculations.

Import a YAML file into Dify Studio as a new Workflow. Before publishing:

1. Set the `backend_url` input to the active HTTPS base URL for port `8000` (not `localhost`, and not port `8001`).
2. Add an HTTP Request header named `X-API-Key`. Store its value as a Dify secret/environment variable named `A2A_API_KEY`; it must match `API_KEY` in the backend `.env`.
3. Publish the workflow.
4. If using the local dashboard's **Run through Dify** button, create a Service API key for that Dify app and set it as `DIFY_API_KEY` in the backend `.env`. This is a different key from `API_KEY` / `A2A_API_KEY`.
5. Set `PUBLIC_BASE_URL` in `.env` to the same active HTTPS base URL, then restart the local app.

The YAML templates intentionally contain no real secrets. The optional LLM template is a starting point; select a model/provider available in your Dify workspace and validate the imported DSL before production use. The LLM is only an explanatory layer; numeric results are produced by Python.

**Network boundary:** expose only backend port `8000` to Dify Cloud over HTTPS. Keep dashboard port `8001` loopback-only. Do not publish an unauthenticated API.

See [the Persian Dify deployment guide](docs/DEPLOYMENT_DIFY_FA.md) for the full walkthrough.

## API overview

Backend (`http://127.0.0.1:8000`):

- `GET /health` — health and configuration status.
- `GET /.well-known/agent-card.json` — orchestrator Agent Card.
- `GET /a2a/{agent_name}/.well-known/agent-card.json` — individual Agent Card.
- `POST /a2a/{agent_name}` — JSON-RPC A2A subset; requires `X-API-Key`.
- `GET /api/scan?top_k=15` — read-only market scan; requires `X-API-Key`.
- `POST /api/paper/preview` — illustrative paper sizing preview; requires `X-API-Key`.

Private UI gateway (`http://127.0.0.1:8001`):

- `GET /api/ui/status`
- `POST /api/ui/scan`
- `POST /api/ui/dify`
- `GET /api/ui/history`

See [API_REFERENCE_FA.md](docs/API_REFERENCE_FA.md) for parameters and details.

## Architecture

The backend first retrieves and validates the available market universe, screens every parsed market, and sends eligible markets to a bounded asynchronous orchestrator. Four analysis agents (orderflow, trend, liquidity, risk) feed a decision agent. Agent calls use JSON-RPC-style requests through an internal ASGI transport in the same process. Dify is an optional external workflow gateway and the LLM variant adds a constrained natural-language explanation after the Python calculation.

See [ARCHITECTURE_EN.md](docs/ARCHITECTURE_EN.md) and [ARCHITECTURE_FA.md](docs/ARCHITECTURE_FA.md).

## Tests and diagnostics

```bash
python -m pytest -q
python -m app.diagnostics
```

`run_diagnostics_windows.bat` runs the diagnostic script on Windows. Tests cover parsing, screening, agent logic, API authentication, local UI integration and Dify interaction with mocks. Passing tests do not validate trading profitability, live exchange uptime, full A2A compliance, or Dify account-specific import compatibility.

## Project structure

```text
app/          FastAPI services, A2A protocol subset, agents and market engine
dashboard/    Local HTML dashboard and labelled legacy synthetic demo
dify/         Importable Dify Workflow YAML files
docs/         Architecture, API and security documentation
outputs/      Explicitly labelled synthetic sample and legacy preview
tests/        Unit and integration tests
```

## Limitations

No OHLC historical backtest, live fill simulation, private balances, account authentication, portfolio tracking, WebSocket market stream, maker/taker fee calibration, or order execution is included. IRT and USDT quote amounts are not directly comparable. Treat all outputs as research/demo material and independently validate any downstream use.

## Author and rights

Created by [Dr. Alireza Hakimi](https://alirezahakimi.ir). Copyright © 2026 Dr. Alireza Hakimi. **All rights reserved; no license to reuse, modify, or redistribute is granted unless a separate license is published.** See [COPYRIGHT.md](COPYRIGHT.md).
