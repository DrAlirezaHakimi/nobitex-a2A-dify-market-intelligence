# Architecture — Nobitex A2A × Dify

## System context

```mermaid
flowchart LR
  N["Nobitex public APIs<br/>bulk orderbook + market stats"] --> ING["Market provider<br/>cache and validation"]
  ING --> PARSE["Market parser<br/>symbol normalization"]
  PARSE --> SCREEN["Fail-closed screening"]
  SCREEN -->|eligible| ORCH["Bounded async orchestrator"]
  SCREEN -->|rejected| REJ["Rejection reasons"]
  ORCH --> OF["Orderflow agent"]
  ORCH --> TR["Trend agent"]
  ORCH --> LQ["Liquidity agent"]
  ORCH --> RK["Risk agent"]
  OF --> DEC["Decision agent"]
  TR --> DEC
  LQ --> DEC
  RK --> DEC
  DEC --> API["FastAPI A2A API :8000"]
  API --> UI["Private UI gateway :8001"]
  UI --> BROWSER["Local browser"]
  UI <-->|"Workflow API"| DIFY["Dify Cloud / self-hosted"]
  DIFY -->|"HTTPS + X-API-Key"| API
  DIFY -.-> LLM["Optional explanatory LLM"]
```

## Runtime components

### Market provider and screening

In `live` mode, the provider retrieves public bulk order-book data and market statistics from Nobitex, caches the snapshot, parses the available spot markets, and applies freshness, market-status, spread, liquidity and data-quality gates. The public release starts in `demo` mode; the operator must explicitly set `MARKET_MODE=live` to use public live snapshots.

### Logical A2A agents

The backend defines five logical agents:

| Agent | Responsibility |
|---|---|
| `orderflow` | Summarizes order-book imbalance and depth |
| `trend` | Evaluates 24-hour change context |
| `liquidity` | Applies liquidity and market-quality constraints |
| `risk` | Computes illustrative quote-denominated size/risk limits |
| `decision` | Combines agent outputs into BUY / SELL / HOLD / BLOCKED-style analytical results |

The agents expose Agent Cards and JSON-RPC-style `message/send` routes. The implementation is a limited subset based on A2A v0.2.6 concepts. All agents run in one Python process; orchestration uses an internal `httpx.ASGITransport` client. This is a modular multi-agent design demonstration, **not** a deployment of five independent network services and not a claim of full protocol/SDK conformance. Streaming, push notifications, persistent tasks, enterprise identity and full transport interoperability are not implemented.

### UI gateway

The UI gateway on port `8001` serves the local dashboard, keeps API keys server-side, calls the local backend for direct scans, optionally calls Dify's Workflow API, and stores limited execution metadata in SQLite. It is restricted to loopback hostnames and local origins. Do not tunnel or expose port `8001`.

### Dify integration

Dify is an optional external workflow layer. Its HTTP Request node calls the protected A2A backend through HTTPS and an `X-API-Key` header. The base workflow formats Python-generated results. The optional LLM workflow adds natural-language explanation after deterministic calculations; the LLM must not change numeric values or issue trade instructions.

## Request flow

1. Read a public market snapshot or synthetic demo dataset.
2. Parse and normalize the available market symbols.
3. Screen all parsed markets; reject stale, malformed, closed, illiquid or wide-spread entries.
4. Submit eligible markets to bounded asynchronous analysis (`MAX_PARALLEL`, `MAX_DEEP`).
5. Run orderflow, trend, liquidity and risk agents, then the decision agent.
6. Return a structured JSON report with metrics, opportunities, method notes and `execution_enabled: false`.
7. Optionally route through Dify and return its report to the local dashboard.

## Network and trust boundaries

- `8000`: backend A2A/API. Requires `X-API-Key` on scan, paper-preview and agent RPC routes. If Dify Cloud needs access, expose this port only through HTTPS.
- `8001`: private local dashboard gateway. Bind to loopback; never expose it to the internet.
- `API_KEY`: backend key in local `.env`; configure the same value as a Dify secret for the HTTP Request `X-API-Key` header.
- `DIFY_API_KEY`: Service API key used by the local UI gateway to call the published Dify workflow; it is a separate credential.
- `PUBLIC_BASE_URL`: active HTTPS public base URL for backend Agent Cards and Dify workflow input.

## Decision semantics

The 0–100 score is an uncalibrated heuristic ranking derived from market microstructure inputs. It is not a win probability, forecast confidence, or expected return. SELL means reducing/exiting an existing spot holding; short selling is not supported. Entry, stop and target levels are arithmetic illustrations and have not been empirically optimized.

## Production gaps

Before production or investment use, this design would require (at minimum) full A2A SDK/spec conformance testing, stronger authentication/authorization, rate limiting, audit and observability, durable task state, historical OHLC data, bias-aware backtesting, walk-forward validation, fee/slippage/fill modeling, paper trading, model/strategy drift monitoring and human approval controls.
