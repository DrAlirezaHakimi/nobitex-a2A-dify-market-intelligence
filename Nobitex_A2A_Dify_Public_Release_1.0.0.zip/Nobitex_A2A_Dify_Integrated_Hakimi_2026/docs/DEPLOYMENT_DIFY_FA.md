# راهنمای اتصال Dify به موتور A2A

این راهنما برای دو مسیر متفاوت است: (الف) اجرای Workflow از داخل Dify Cloud و (ب) فراخوانی همان Workflow از داشبورد محلی.

## ۱. تفاوت کلیدها

| نام | محل نگهداری | کاربرد |
|---|---|---|
| `API_KEY` | فایل `.env` روی سرور Python | محافظت از Backend A2A |
| `A2A_API_KEY` | متغیر محرمانه در Dify Workflow | مقدار هدر `X-API-Key` نود HTTP؛ باید با `API_KEY` برابر باشد |
| `DIFY_API_KEY` | فایل `.env` روی سرور Python | کلید Service API اپلیکیشن Dify برای داشبورد محلی؛ با دو کلید دیگر فرق دارد |
| ngrok authtoken | پیکربندی محلی ngrok | احراز هویت خود ngrok؛ نباید در پروژه یا Dify قرار گیرد |

## ۲. راه‌اندازی Backend

1. در ویندوز `start_windows.bat` را اجرا کنید.
2. `.env` به‌صورت محلی ایجاد می‌شود و در نسخه عمومی `MARKET_MODE=demo` است.
3. داشبورد محلی روی `http://127.0.0.1:8001` و Backend روی `http://127.0.0.1:8000` است.
4. برای استفاده از داده عمومی واقعی، `MARKET_MODE=live` را در `.env` تنظیم و سرویس را restart کنید.
5. تونل HTTPS را فقط به پورت 8000 متصل کنید. برای نمونه:

```bash
ngrok http 8000
```

آدرس HTTPS فعال را نگه دارید؛ آن را در GitHub commit نکنید. پورت 8001 را عمومی نکنید.

## ۳. Import کردن Workflow پایه

1. در Dify Studio یک Workflow جدید بسازید.
2. از گزینه Import DSL، فایل `dify/Hakimi_Nobitex_A2A_Gateway.yaml` را وارد کنید.
3. در ورودی `backend_url` آدرس HTTPS تونل فعال را وارد کنید؛ دامنه باید به پورت 8000 برسد.
4. در تنظیمات Workflow یک متغیر محرمانه با نام `A2A_API_KEY` بسازید.
5. در نود HTTP Request، یک Header با نام `X-API-Key` اضافه کنید و مقدار را از متغیر محرمانه `A2A_API_KEY` بگیرید.
6. مقدار `A2A_API_KEY` باید دقیقاً با `API_KEY` در فایل `.env` Backend برابر باشد.
7. Workflow را Test Run و سپس Publish کنید.

فایل YAML عمداً مقدار کلید را در خود ندارد. پس از Import باید Header و Secret را در محیط Dify تنظیم کنید؛ کلید را در YAML، پیام، اسکرین‌شات یا مخزن عمومی قرار ندهید.

## ۴. فعال‌سازی نسخه LLM اختیاری

فایل `dify/Hakimi_A2A_Optional_LLM_Explainer.yaml` یک Workflow جداگانه است که پس از محاسبات Python یک نود LLM برای توضیح متنی اضافه می‌کند.

- فایل را به‌عنوان یک اپلیکیشن Workflow جدید Import کنید.
- همان `backend_url` و Header محرمانه `X-API-Key` را تنظیم کنید.
- در نود LLM، Provider و مدلی را انتخاب کنید که در حساب Dify شما فعال است؛ نام مدل داخل DSL صرفاً نمونه است.
- خروجی LLM باید فقط توضیح داده‌ها باشد؛ نمره‌ها، قیمت‌ها و تصمیم محاسباتی را تغییر ندهد.
- Test Run بگیرید و سپس Publish کنید.

این DSL اختیاری ممکن است بر اساس نسخه Dify یا Provider حساب شما به اصلاح نیاز داشته باشد؛ سازگاری آن با هر حسابی تضمین نشده است.

## ۵. اتصال داشبورد محلی به Dify

برای دکمه «اجرای تحلیل از Dify» در داشبورد:

1. از Access Point اپلیکیشن Dify، یک Service API Key بسازید.
2. آن را در `.env` سرور محلی در `DIFY_API_KEY` قرار دهید.
3. `PUBLIC_BASE_URL` را برابر همان HTTPS URL فعال Backend (بدون اسلش انتهایی) تنظیم کنید.
4. `DIFY_API_BASE` را مطابق استقرار خود تنظیم کنید؛ مقدار پیش‌فرض Cloud برابر `https://api.dify.ai/v1` است.
5. سرویس Python را restart کنید.
6. از داشبورد روی اجرای Dify بزنید.

کلید Service API برای فراخوانی Dify از داشبورد است و نباید به‌جای `A2A_API_KEY` در Header نود HTTP استفاده شود.

## ۶. عیب‌یابی

- `401`: مقدار `X-API-Key` در Dify با `API_KEY` Backend برابر نیست یا Header ارسال نشده است.
- `404`: Workflow منتشر نشده، مسیر API اشتباه است یا اپلیکیشن موردنظر در دسترس نیست.
- `503`: Backend به داده بازار دسترسی ندارد، کلید تنظیم نشده یا داده تازه در دسترس نیست.
- Dify status not ready: `DIFY_API_KEY`، `PUBLIC_BASE_URL` یا انتشار Workflow را بررسی کنید.
- خطای اتصال از Dify Cloud: مطمئن شوید URL عمومی HTTPS است و به پورت 8000 می‌رسد؛ `127.0.0.1` از Cloud قابل دسترسی نیست.
- در تغییر Environment Variable در Dify، Workflow را دوباره Publish کنید.

## ۷. مرز امنیتی

پورت 8001 فقط برای داشبورد محلی است. تنها Backend روی پورت 8000 می‌تواند در صورت نیاز از HTTPS قابل دسترسی باشد. API را بدون احراز هویت، محدودیت نرخ و TLS عمومی نکنید.
