# مرجع API — نسخه عمومی

تمام مسیرها روی Backend با پایه `http://127.0.0.1:8000` و مسیرهای داشبورد با پایه `http://127.0.0.1:8001` ارائه می‌شوند. مسیرهای محافظت‌شده Backend نیازمند Header زیر هستند:

```http
X-API-Key: <API_KEY>
```

## Backend A2A/API — پورت 8000

| Method | Path | احراز هویت | توضیح |
|---|---|---|---|
| GET | `/` | عمومی | اطلاعات سرویس؛ تصریح می‌کند داشبورد عمومی نیست و اجرا غیرفعال است |
| GET | `/health` | عمومی | وضعیت سلامت، حالت داده و فهرست Agentها |
| GET | `/.well-known/agent-card.json` | عمومی | Agent Card هماهنگ‌کننده |
| GET | `/.well-known/agent.json` | عمومی | مسیر جایگزین Agent Card هماهنگ‌کننده |
| GET | `/a2a/{agent_name}/.well-known/agent-card.json` | عمومی | Agent Card یک عامل |
| GET | `/a2a/{agent_name}/.well-known/agent.json` | عمومی | مسیر جایگزین Agent Card عامل |
| POST | `/a2a/{agent_name}` | `X-API-Key` | JSON-RPC subset برای `message/send` و `tasks/get` |
| GET | `/api/scan` | `X-API-Key` | اسکن read-only بازار |
| POST | `/api/paper/preview` | `X-API-Key` | محاسبه نمایشی اندازه/ریسک؛ بدون سفارش |

### نام عامل‌ها

`orderflow`، `trend`، `liquidity`، `risk` و `decision`.

### پارامترهای GET `/api/scan`

| Query | نوع | پیش‌فرض | دامنه |
|---|---|---:|---|
| `top_k` | integer | 12 | 1 تا 100 |
| `budget_irt` | number | 100000000 | بزرگ‌تر از صفر |
| `budget_usdt` | number | 1000 | بزرگ‌تر از صفر |
| `fee_bps` | number | 30 | 0 تا 200 |

خروجی شامل `mode`، `data_status`، `metrics`، `opportunities`، `market_universe`، `method` و `execution_enabled: false` است. مقدار `score` امتیاز اکتشافی است و احتمال موفقیت نیست.

### POST `/api/paper/preview`

نمونه Body:

```json
{
  "symbol": "BTCIRT",
  "side": "BUY",
  "capital_quote": 100000000,
  "fee_bps_per_side": 30,
  "stop_distance_pct": 2.0,
  "risk_fraction": 0.005
}
```

`side` فقط `BUY` یا `SELL` است. SELL به موجودی اسپات قبلی نیاز دارد. خروجی `paper_only: true` دارد و هیچ سفارشی ثبت نمی‌کند.

## داشبورد خصوصی — پورت 8001

| Method | Path | توضیح |
|---|---|---|
| GET | `/` | فایل HTML داشبورد |
| GET | `/api/ui/status` | وضعیت سرویس‌ها و پیکربندی |
| POST | `/api/ui/scan` | اجرای اسکن مستقیم از Backend |
| POST | `/api/ui/dify` | اجرای Workflow منتشرشده Dify |
| GET | `/api/ui/history` | ۵۰ رکورد اخیر metadata اسکن |

نمونه Body برای دو POST داشبورد:

```json
{"top_k": 15}
```

این UI به loopback محدود است و نباید از طریق ngrok یا reverse proxy عمومی شود.

## خطاهای متداول

- `401`: کلید `X-API-Key` نامعتبر یا ارسال‌نشده است.
- `503`: تنظیم `API_KEY` ناقص است یا داده بازار در دسترس نیست.
- `502`: پاسخ Backend یا Dify نامعتبر است.
- `404`: عامل ناشناخته، بازار ناموجود یا Workflow منتشرنشده.
