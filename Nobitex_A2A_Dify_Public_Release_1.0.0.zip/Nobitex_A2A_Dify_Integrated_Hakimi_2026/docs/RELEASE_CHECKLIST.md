# Public release checklist

- [x] No `.env` or local SQLite database in release tree.
- [x] `.env.example` contains placeholders only.
- [x] First-run defaults are `demo`; `live` requires explicit opt-in.
- [x] Dashboard remains loopback-only; only backend port 8000 is intended for optional HTTPS exposure.
- [x] Dify workflow templates contain no actual credentials.
- [x] Synthetic sample files are explicitly labelled.
- [x] Tests pass locally (`python -m pytest -q`).
- [x] Documentation distinguishes logical in-process agents from separately deployed services.
- [x] Documentation states that A2A support is a limited JSON-RPC subset, not full SDK/spec conformance.
- [x] Documentation states that scores are uncalibrated heuristics and real trading is disabled.
- [ ] Verify the GitHub repository URL and public visibility after creation.
- [ ] Verify GitHub Actions on the initial public commit.

- [x] Bilingual, offline-friendly step-by-step HTML user guide included and linked from the READMEs.
