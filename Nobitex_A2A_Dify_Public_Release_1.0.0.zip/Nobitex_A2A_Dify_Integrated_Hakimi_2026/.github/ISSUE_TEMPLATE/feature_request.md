---
name: Feature request
about: Suggest a focused improvement
labels: enhancement
---

## Problem to solve

## Proposed change

## Alternatives considered

## Security, data quality or financial-risk implications
