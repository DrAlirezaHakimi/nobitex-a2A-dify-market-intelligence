---
name: Bug report
about: Report a reproducible defect
labels: bug
---

## Summary

## Environment
- OS:
- Python version:
- Project version / commit:
- Market mode (`demo` or `live`):

## Steps to reproduce

## Expected behavior

## Actual behavior / sanitized logs

> Remove API keys, tokens, URLs containing private identifiers, account information and personal data before posting.
