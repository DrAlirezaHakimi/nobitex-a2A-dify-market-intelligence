# Nobitex A2A × Dify — Market Intelligence

**A read-only, multi-agent market-analysis demonstration** built with Python, FastAPI, a JSON-RPC A2A subset, a local dashboard, and optional Dify/LLM workflow integration.

> **Safety first:** the public release starts in `demo` mode. `live` mode reads public Nobitex market data only. The application does not connect to private exchange accounts and does not place orders. Scores are heuristic rankings, not probabilities of profit.

**Author:** [Dr. Alireza Hakimi](https://alirezahakimi.ir) · [GitHub](https://github.com/DrAlirezaHakimi)

## Documentation

- [Interactive bilingual step-by-step setup guide (HTML)](USER_GUIDE_BILINGUAL.html)

- [English documentation](README_EN.md)
- [راهنمای فارسی](README_FA.md)
- [Architecture (English)](docs/ARCHITECTURE_EN.md)
- [معماری فارسی](docs/ARCHITECTURE_FA.md)
- [Dify deployment guide (Persian)](docs/DEPLOYMENT_DIFY_FA.md)
- [API reference (Persian)](docs/API_REFERENCE_FA.md)
- [Security policy](SECURITY.md) · [Security notes (Persian)](docs/SECURITY_FA.md)

## Quick start (Windows)

1. Install Python 3.12 or newer.
2. Extract the project and run `start_windows.bat`.
3. Open <http://127.0.0.1:8001>.
4. The first run uses synthetic `demo` data. To opt into public Nobitex market data, edit `.env` and set `MARKET_MODE=live`, then restart.

See [README_EN.md](README_EN.md) or [README_FA.md](README_FA.md) for the complete setup and Dify instructions.

## Architecture at a glance

```mermaid
flowchart LR
  N[Nobitex public market API] --> I[Market ingestion and cache]
  I --> S[Screening and data-quality gates]
  S --> O[Bounded Python orchestrator]
  O --> A1[Orderflow agent]
  O --> A2[Trend agent]
  O --> A3[Liquidity agent]
  O --> A4[Risk agent]
  A1 --> D[Decision agent]
  A2 --> D
  A3 --> D
  A4 --> D
  D --> API[FastAPI A2A API :8000]
  API --> UI[Private dashboard gateway :8001]
  API <--> DF[Dify Workflow over HTTPS]
  DF --> LLM[Optional explanatory LLM]
```

## Important implementation boundary

The five agents are logical agents exposed through an A2A/JSON-RPC subset. In this release they run in one Python process and are invoked through an internal ASGI transport; they are **not** five separately deployed microservices. The optional Dify LLM explains Python-generated results and does not determine or alter the numeric score.

## Repository status

This repository is published for inspection, demonstration, and research. **All rights reserved; no license to reuse, modify, or redistribute is granted unless the author publishes a separate license.**

© 2026 [Dr. Alireza Hakimi](https://alirezahakimi.ir). See [COPYRIGHT.md](COPYRIGHT.md).
